
class AppIcons{

  // String path = 'assets/icons/';


 static const String petrolStation = 'assets/icons/petroStation.png';
 static const String searchIcon = 'assets/icons/search.png';
 static const String crossIcon = 'assets/icons/cross.png';
 static const String infoIcon = 'assets/icons/info.png';
 static const String arrowLeft = 'assets/icons/arrowLeft.png';
 static const String arrowRight = 'assets/icons/arrowRight.png';
 static const String cardAdd = 'assets/icons/cardAdd.png';
 static const String profileIcon = 'assets/icons/profile.png';
 static const String supportIcon = 'assets/icons/support.png';
 static const String subscriptionIcon = 'assets/icons/subscrip.png';
 static const String settingIcon = 'assets/icons/setting.png';
 static const String drivingRulesIcon = 'assets/icons/drivingRules.png';
 static const String privacyPolicyIcon = 'assets/icons/privacyPolicy.png';
 static const String aboutUsIcon = 'assets/icons/aboutUs.png';
}

class AppImages{

 static const String skoty = 'assets/images/skot.svg';
 static const String profile = 'assets/images/profile.png';
}